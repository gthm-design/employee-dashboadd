import { useState } from "react";
import { Container, Form, Button, Alert, Card } from "react-bootstrap";

const EMPTY = { name: "", designation: "", location: "", salary: "" };

export default function EmployeeForm() {
  const [form, setForm] = useState(EMPTY);
  const [saved, setSaved] = useState(null);

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Employee submitted:", form);
    setSaved(form);
    setForm(EMPTY);
  };

  return (
    <Container className="my-4" style={{ maxWidth: 560 }}>
      <h2 className="mb-3">Employee Form</h2>

      {saved && (
        <Alert variant="success" dismissible onClose={() => setSaved(null)}>
          {saved.name} ({saved.designation}, {saved.location}) was saved with a
          salary of {saved.salary}.
        </Alert>
      )}

      <Card body>
        <Form onSubmit={handleSubmit}>
          <Form.Group className="mb-3" controlId="name">
            <Form.Label>Name</Form.Label>
            <Form.Control name="name" value={form.name} onChange={handleChange} required />
          </Form.Group>

          <Form.Group className="mb-3" controlId="designation">
            <Form.Label>Designation</Form.Label>
            <Form.Control name="designation" value={form.designation} onChange={handleChange} required />
          </Form.Group>

          <Form.Group className="mb-3" controlId="location">
            <Form.Label>Location</Form.Label>
            <Form.Control name="location" value={form.location} onChange={handleChange} required />
          </Form.Group>

          <Form.Group className="mb-3" controlId="salary">
            <Form.Label>Salary</Form.Label>
            <Form.Control type="number" min="0" name="salary" value={form.salary} onChange={handleChange} required />
          </Form.Group>

          <Button type="submit" variant="primary">Save employee</Button>
        </Form>
      </Card>
    </Container>
  );
}
