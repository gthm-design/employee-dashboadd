# Employee Dashboard (React + React Router + Bootstrap)

## Setup
```bash
npm create vite@latest employee-dashboard -- --template react
cd employee-dashboard
npm install react-router-dom bootstrap react-bootstrap
```
Delete the generated `src/App.jsx`, `src/main.jsx`, `src/App.css`, `src/index.css`,
then copy this project's `src/` folder over it.

## Run
```bash
npm run dev
```
Open http://localhost:5173

## Routes
- `/`              -> Home / Employee Dashboard (users from jsonplaceholder: id, name, email)
- `/employee-form` -> Employee Form (Name, Designation, Location, Salary)
